requirements:

tensorflow == '1.13.1'
pandas == '0.25.0'
numpy == '1.16.4'

