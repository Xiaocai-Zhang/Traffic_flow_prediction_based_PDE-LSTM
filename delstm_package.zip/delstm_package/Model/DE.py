# -*- coding: utf-8 -*-
import numpy as np
import random


class DEAlgorithm:
    def __init__(self,config):
        self.config = config

    def inrange(self,mutated):
        '''
        determine the initialized population is in the bounds
        :param mutated: population after mutation
        :return: True or False
        '''
        seq = mutated[0]
        epo = mutated[1]
        hid = mutated[2]
        bat = mutated[3]
        lr = mutated[4]
        seqb = self.config.bounds[0]
        epob = self.config.bounds[1]
        hidb = self.config.bounds[2]
        batb = self.config.bounds[3]
        lrb = self.config.bounds[4]

        if seq>=seqb[0] and seq<=seqb[1] and epo>=epob[0] and epo<=epob[1] and hid>=hidb[0] and hid<=hidb[1] and bat>=batb[0] and bat<=batb[1] and lr>=lrb[0] and lr<=lrb[1]:
            return True
        else:
            return False

    def initialization(self):
        '''
        initialize population
        :return: initialized population
        '''
        ArryLi = []
        for i in range(self.config.popsize):
            initLi = []
            for bound in self.config.bounds:
                init = np.random.uniform(low=bound[0], high=bound[1], size=1)
                initLi.append(init[0])
            ArryLi.append(initLi)

        return ArryLi

    def listadd(self,l1,l2):
        '''
        function to add two list
        :param l1: list1
        :param l2: list2
        :return: added list
        '''
        out = [a+b for a,b in zip(l1,l2)]
        return out

    def multply(self,a,li):
        '''
        function to multply two lists a*list
        :param a: a scalar
        :param li: a list
        :return: a list
        '''
        out = [a*b for b in li]
        return out

    def listminus(self,l1,l2):
        '''
        two list minus
        :param l1: list 1
        :param l2: list 2
        :return: minus list
        '''
        out = [a-b for a,b in zip(l1,l2)]
        return out

    def mutation(self,InitialArray):
        '''
        mutation function
        :param InitialArray: initialized population
        :return: mutated population
        '''
        ArryLi = InitialArray.copy()
        random.seed(self.config.seed)
        for i in range(len(ArryLi)):
            Contin = True
            while Contin:
                F = np.random.uniform(low=self.config.F_l, high=self.config.F_u, size=1)[0]
                idxlist = list(range(len(ArryLi)))
                idxlist.remove(i)
                idxLI = random.sample(idxlist, 3)
                mu_a = self.listminus(ArryLi[idxLI[1]],ArryLi[idxLI[2]])
                mu_b = self.multply(F,mu_a)
                mu_c = self.listadd(ArryLi[idxLI[0]],mu_b)
                if self.inrange(mu_c):
                    ArryLi[i] = mu_c
                    Contin = False

        return ArryLi

    def crossover(self,InitialArray,MutatedArray):
        '''
        crossover function
        :param InitialArray: initialized population
        :param MutatedArray: mutated population
        :return: crossovered population
        '''
        CrossArray = []
        for i in range(len(InitialArray)):
            arry = []
            for j in range(len(InitialArray[i])):
                Fc = np.random.uniform(low=0, high=1, size=1)[0]
                if Fc >= self.config.F_c:
                    arry.append(MutatedArray[i][j])
                else:
                    arry.append(InitialArray[i][j])

            CrossArray.append(arry)

        return CrossArray

    def selection(self,mapelist,InitialArray,CrossArray):
        '''
        selection function
        :param mapelist: fitness list
        :param InitialArray: initialized population
        :param CrossArray: crossovered population
        :return: selectArray: selected population; BestMape: best fitness value (mape)
        '''
        BestMape = []
        selectArray = []
        for i in range(self.config.popsize):
            mapeIni = mapelist[i]
            mapeCros = mapelist[i+self.config.popsize]
            if mapeIni>mapeCros:
                BestMape.append(mapeCros)
                selectArray.append(CrossArray[i])
            else:
                BestMape.append(mapeIni)
                selectArray.append(InitialArray[i])

        return selectArray,BestMape


