import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import tensorflow as tf
from Model.DE import DEAlgorithm
import pandas as pd
import numpy as np
import copy
from datetime import datetime
import multiprocessing as mp


class config:
    '''
    define parameters and paths
    '''
    PathData = './Data/M1-N/D_45m.csv'
    PathSave = "./Saved/checkpoint/M1-N/DELSTM_45m/"
    maxiter = 10
    popsize = 40
    bounds = [(1, 50), (10, 1000), (1, 75), (10, 500), (0.001,0.1)]
    F_l = 0.5
    F_u = 1
    F_c = 0.7
    EarlyStopStep = 3
    seed = 5

# read data
Data = pd.read_csv(config.PathData)
Data_spare = copy.deepcopy(Data)

# Split data into training, validation and test sets
D_train = Data.iloc[128:8928,:]
max_train = D_train['V1'].max()
min_train = D_train['V1'].min()

# normalization
Data['V1'] = (Data['V1'] - min_train) / (max_train - min_train)


def perform(x):
    '''
    :param x: [sequence length, max epoch, hidden unit, batch, learning rate]
    :return: fitness value (mape)
    '''
    tf.reset_default_graph()
    from tensorflow import set_random_seed
    set_random_seed(10)

    m = int(round(x[0]))
    epoch = int(round(x[1]))
    num_hidden = int(round(x[2]))
    batch_size = int(round(x[3]))
    learn_rate = round(x[4],4)
    n_classes = 1
    n_features = m

    X_train = []
    Y_train = []
    for i in range(128,8928):
        y = Data_spare.iloc[i, 0]
        Y_train.append(np.array(y).reshape([1]))
        x = Data.iloc[(i - m):i, 0]
        X_train.append(np.array(x).reshape([m, 1]))

    X_val = []
    Y_val = []
    for i in range(8928,9920):
        y = Data_spare.iloc[i, 0]
        Y_val.append(np.array(y).reshape([1]))
        x = Data.iloc[(i - m):i, 0]
        X_val.append(np.array(x).reshape([m, 1]))

    data = tf.placeholder(tf.float32, [None, n_features, 1])
    target = tf.placeholder(tf.float32, [None, n_classes])

    with tf.variable_scope('forward'):
        cell = tf.nn.rnn_cell.LSTMCell(num_hidden, state_is_tuple=True)
    val, _ = tf.nn.dynamic_rnn(cell, data, dtype=tf.float32)
    val = tf.transpose(val, [1, 0, 2])
    last = tf.gather(val, int(val.get_shape()[0]) - 1)

    weight = tf.Variable(tf.truncated_normal([num_hidden, int(target.get_shape()[1])]))
    bias = tf.Variable(tf.constant(0.1, shape=[target.get_shape()[1]]))
    prediction = (tf.matmul(last, weight) + bias) * (max_train - min_train) + min_train

    cost = tf.losses.mean_squared_error(prediction, target)
    optimizer = tf.train.RMSPropOptimizer(learning_rate=learn_rate).minimize(cost)

    init_op = tf.global_variables_initializer()
    saver = tf.train.Saver()
    sess = tf.Session()
    sess.run(init_op)

    no_of_batches = int(len(X_train) / batch_size)
    mape_min = 1000
    for i in range(epoch):
        ptr = 0
        epoch_loss = 0
        for j in range(no_of_batches):
            inp, out = X_train[ptr:ptr + batch_size], Y_train[ptr:ptr + batch_size]
            _, c = sess.run([optimizer, cost], feed_dict={data: inp, target: out})
            ptr += batch_size
            epoch_loss += c

        pred = sess.run(tf.round(prediction), feed_dict={data: X_val})
        mape = np.mean(np.abs(pred - np.array(Y_val)) / np.abs(np.array(Y_val))) * 100

        if mape<mape_min:
            mape_min = mape
            saver.save(sess, config.PathSave+'m'+str(m)+"_"+str(epoch)+"_"+str(num_hidden)+"_"+str(batch_size)+"_"+str(learn_rate)+".ckpt")

    print("MAPE: ", str(mape_min), "%", 'm:', m, 'epoch:', epoch, 'hidden:', num_hidden, 'batch size:', batch_size, 'learning rate:',learn_rate)
    sess.close()

    return mape_min


if __name__ == '__main__':
    start = datetime.now()
    print(start)

    np.random.seed(config.seed)

    DEAlgorithm = DEAlgorithm(config)
    InitialArray = DEAlgorithm.initialization()

    GlobalMinValLi = []
    GlobalMinVal = 1000
    for step in range(config.maxiter):
        MutatedArray = DEAlgorithm.mutation(InitialArray)
        CrossArray = DEAlgorithm.crossover(InitialArray, MutatedArray)

        if step==0:
            args = InitialArray+CrossArray
            CombineArray = args
        else:
            args = CrossArray
            CombineArray = InitialArray+CrossArray

        processor = mp.cpu_count()

        # parallel computing
        p = mp.Pool(processes=processor)
        mapelist = p.map(perform, args)
        p.close()
        p.join()

        if step==0:
            mapeList = mapelist
        else:
            mapeList = BestMape + mapelist

        StepMinVal = min(mapeList)

        if StepMinVal<GlobalMinVal:
            LIdx = mapeList.index(StepMinVal)
            StepOptimalPara = CombineArray[LIdx]
            GlobalOptimalPara = StepOptimalPara
            GlobalMinVal = StepMinVal

        print("Step: %s, min MAPE: %s, hyperparameter: %s" %(step,GlobalMinVal,GlobalOptimalPara))
        SelectArray,BestMape = DEAlgorithm.selection(mapeList,InitialArray,CrossArray)
        InitialArray = SelectArray

        # early stopping applied
        GlobalMinValLi.append(GlobalMinVal)
        if step+1>=config.EarlyStopStep:
            if GlobalMinValLi[-1]==GlobalMinValLi[-2]==GlobalMinValLi[-3]:
                break

    print('Finish!')
    print("Optimal MAPE: %s, hyperparameter: %s" % (GlobalMinVal, GlobalOptimalPara))
    print(datetime.now() - start)
