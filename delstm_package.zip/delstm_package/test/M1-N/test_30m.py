import tensorflow as tf
import pandas as pd
import numpy as np
import copy
from datetime import datetime
import os

start=datetime.now()

HomePath = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# read data
Data = pd.read_csv(HomePath+'/Data/M1-N/D_30m.csv')
Data_spare = copy.deepcopy(Data)

# Split data into training, validation and test sets
D_train = Data.iloc[192:13392,:]
max_train = D_train['V1'].max()
min_train = D_train['V1'].min()

# normalization
Data['V1'] = (Data['V1']-min_train)/(max_train-min_train)

# optimal hyperparameters
m = 32
epoch = 957
num_hidden = 33
batch_size = 268
learn_rate = 0.0067

n_classes = 1
n_features = m

X_train = []
Y_train = []
for i in range(192,13392):
	y = Data_spare.iloc[i,0]
	Y_train.append(np.array(y).reshape([1]))
	x = Data.iloc[(i-m):i,0]
	X_train.append(np.array(x).reshape([m,1]))	

X_val = []
Y_val = []
for i in range(13392,14880):
	y = Data_spare.iloc[i,0]
	Y_val.append(np.array(y).reshape([1]))
	x = Data.iloc[(i-m):i,0]
	X_val.append(np.array(x).reshape([m,1]))	
	
X_test = []
Y_test = []
for i in range(14880,17712):
	y = Data_spare.iloc[i,0]
	Y_test.append(np.array(y).reshape([1]))
	x = Data.iloc[(i-m):i,0]
	X_test.append(np.array(x).reshape([m,1]))

data = tf.placeholder(tf.float32, [None, n_features, 1])
target = tf.placeholder(tf.float32, [None, n_classes])

cell = tf.nn.rnn_cell.LSTMCell(num_hidden,state_is_tuple=True)
val, _ = tf.nn.dynamic_rnn(cell, data, dtype=tf.float32)
val = tf.transpose(val, [1, 0, 2])
last = tf.gather(val, int(val.get_shape()[0]) - 1)

weight = tf.Variable(tf.truncated_normal([num_hidden, int(target.get_shape()[1])]))
bias = tf.Variable(tf.constant(0.1, shape=[target.get_shape()[1]]))
prediction = (tf.matmul(last, weight) + bias)*(max_train-min_train) + min_train

cost = tf.losses.mean_squared_error(prediction, target)
optimizer = tf.train.RMSPropOptimizer(learning_rate = learn_rate).minimize(cost)

init_op = tf.global_variables_initializer()
saver = tf.train.Saver()
sess = tf.Session()
sess.run(init_op)
saver.restore(sess, HomePath+"/Saved/checkpoint/M1-N/DELSTM_30m/m"+str(m)+"_"+str(epoch)+"_"+str(num_hidden)+"_"+str(batch_size)+"_"+str(learn_rate)+".ckpt")

pred = sess.run(tf.round(prediction), feed_dict={data: X_test})

# evaluation
mae = np.mean(np.abs(pred-np.array(Y_test)))
mse = np.mean(np.power(np.abs(pred-np.array(Y_test)),2))
rmse = np.sqrt(mse)
mape = np.mean(np.abs(pred-np.array(Y_test)) / np.abs(np.array(Y_test)))*100

np.savetxt(HomePath+'/Saved/predicted_flow/M1-N/predicted_30m.csv',pred,delimiter=",")

print ("MAE: ", str(mae))
print ("RMSE: ", str(rmse))
print ("MAPE: ", str(mape), "%")
sess.close()
print (datetime.now()-start)
