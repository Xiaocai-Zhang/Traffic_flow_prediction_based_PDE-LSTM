requirements:

tensorflow==1.13.1
pandas==0.24.1
numpy==1.16.1
scipy==1.2.1

