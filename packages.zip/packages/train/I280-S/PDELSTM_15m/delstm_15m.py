
import tensorflow as tf
import pandas as pd
import numpy as np
import copy
from scipy.optimize import differential_evolution
from datetime import datetime

start=datetime.now()

Data = pd.read_csv('../../../data/I280-S/D_15m.csv')

Data_spare = copy.deepcopy(Data)

# Split data----first 9 months as training set, the following 1 month as validation set, the last 2 months as test set
D_train = Data.iloc[384:26784,:]
max_train = D_train['V1'].max()
min_train = D_train['V1'].min()

# normilization
Data['V1'] = (Data['V1']-min_train)/(max_train-min_train)
nn = 0
def func_optim(x):
	tf.reset_default_graph()
	global nn
	nn = nn+1
	m = int(round(x[0]))
	epoch = int(round(x[1]))
	num_hidden = int(round(x[2]))
	batch_size = int(round(x[3]))
	n_classes = 1
	n_features = m
	learn_rate = 0.002

	X_train = []
	Y_train = []
	for i in range(384,26784):
		y = Data_spare.iloc[i,0]
		Y_train.append(np.array(y).reshape([1]))
		x = Data.iloc[(i-m):i,0]
		X_train.append(np.array(x).reshape([m,1]))	

	X_val = []
	Y_val = []
	for i in range(26784,29760):
		y = Data_spare.iloc[i,0]
		Y_val.append(np.array(y).reshape([1]))
		x = Data.iloc[(i-m):i,0]
		X_val.append(np.array(x).reshape([m,1]))	
		
	X_test = []
	Y_test = []
	for i in range(29760,35424):
		y = Data_spare.iloc[i,0]
		Y_test.append(np.array(y).reshape([1]))
		x = Data.iloc[(i-m):i,0]
		X_test.append(np.array(x).reshape([m,1]))

	data = tf.placeholder(tf.float32, [None, n_features, 1])
	target = tf.placeholder(tf.float32, [None, n_classes])
	
	with tf.variable_scope('forward'):
		cell = tf.nn.rnn_cell.LSTMCell(num_hidden,state_is_tuple=True)
	val, _ = tf.nn.dynamic_rnn(cell, data, dtype=tf.float32)
	val = tf.transpose(val, [1, 0, 2])
	last = tf.gather(val, int(val.get_shape()[0]) - 1)

	weight = tf.Variable(tf.truncated_normal([num_hidden, int(target.get_shape()[1])]))
	bias = tf.Variable(tf.constant(0.1, shape=[target.get_shape()[1]]))
	prediction = (tf.matmul(last, weight) + bias)*(max_train-min_train) + min_train

	cost = tf.losses.mean_squared_error(prediction, target)
	optimizer = tf.train.RMSPropOptimizer(learning_rate = learn_rate).minimize(cost)

	init_op = tf.global_variables_initializer()
	saver = tf.train.Saver()
	sess = tf.Session()
	sess.run(init_op)

	no_of_batches = int(len(X_train) / batch_size)
	for i in range(epoch):
		ptr = 0
		epoch_loss = 0
		for j in range(no_of_batches):
			inp, out = X_train[ptr:ptr+batch_size], Y_train[ptr:ptr+batch_size]
			_, c = sess.run([optimizer, cost], feed_dict={data: inp, target: out})
			ptr+=batch_size
			epoch_loss += c
		
	pred = sess.run(tf.round(prediction), feed_dict={data: X_val})

	# calculate fitness value
	mape = np.mean(np.abs(pred-np.array(Y_val)) / np.abs(np.array(Y_val)))*100

	print ("No.:", nn, "MAPE: ", str(mape), "%", 'm:', m, 'epoch:', epoch, 'hidden:', num_hidden, 'batch size:', batch_size)

	# save models
	save_path = saver.save(sess, "../../../model/I280-S/PDELSTM_15m/m"+str(m)+"_"+str(epoch)+"_"+str(num_hidden)+"_"+str(batch_size)+".ckpt")
	sess.close()
	return mape	


# parameters
length_min = 1  # lower bound of sequence length
length_max = 30 # upper bound of sequence length
epoch_min = 1 # lower bound of epoch
epoch_max = 1000  # upper bound of epoch
hidden_unit_min = 1 # lower bound of hidden unit
hidden_unit_max = 50 # upper bound of hidden unit
batch_size_min = 10 # lower bound of batch size
batch_size_max = 500 # upper bound of batch size
maxG = 15 # maximum iteration
N = 16 # population size

bounds = [(length_min, length_max), (epoch_min, epoch_max), (hidden_unit_min, hidden_unit_max), (batch_size_min, batch_size_max)]

# call parallel differential evolution based lstm
result = differential_evolution(func_optim, bounds, maxiter=maxG, popsize=N, disp=True, polish=False, updating='deferred', workers=-1)
print (result.x)
print (result.fun)
print (datetime.now()-start)


