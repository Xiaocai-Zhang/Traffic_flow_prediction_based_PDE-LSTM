import tensorflow as tf
import pandas as pd
import numpy as np
import copy
from datetime import datetime

start=datetime.now()

Data = pd.read_csv('../../../data/I280-S/D_45m.csv')
Data_spare = copy.deepcopy(Data)

# Split data----first 9 months as training set, the following 1 month as validation set, the last 2 months as test set
D_train = Data.iloc[128:8928,:]
max_train = D_train['V1'].max()
min_train = D_train['V1'].min()

# normilization
Data['V1'] = (Data['V1']-min_train)/(max_train-min_train)

# Optimal Hyperparameters
m = 22 # sequence length
epoch = 263 # epoch
num_hidden = 41 # hidden unit
batch_size = 80 # batch size

n_classes = 1
n_features = m
learn_rate = 0.002

X_train = []
Y_train = []
for i in range(128,8928):
	y = Data_spare.iloc[i,0]
	Y_train.append(np.array(y).reshape([1]))
	x = Data.iloc[(i-m):i,0]
	X_train.append(np.array(x).reshape([m,1]))	

X_val = []
Y_val = []
for i in range(8928,9920):
	y = Data_spare.iloc[i,0]
	Y_val.append(np.array(y).reshape([1]))
	x = Data.iloc[(i-m):i,0]
	X_val.append(np.array(x).reshape([m,1]))	
	
X_test = []
Y_test = []
for i in range(9920,11808):
	y = Data_spare.iloc[i,0]
	Y_test.append(np.array(y).reshape([1]))
	x = Data.iloc[(i-m):i,0]
	X_test.append(np.array(x).reshape([m,1]))

data = tf.placeholder(tf.float32, [None, n_features, 1])
target = tf.placeholder(tf.float32, [None, n_classes])

cell = tf.nn.rnn_cell.LSTMCell(num_hidden,state_is_tuple=True)
val, _ = tf.nn.dynamic_rnn(cell, data, dtype=tf.float32)
val = tf.transpose(val, [1, 0, 2])
last = tf.gather(val, int(val.get_shape()[0]) - 1)

weight = tf.Variable(tf.truncated_normal([num_hidden, int(target.get_shape()[1])]))
bias = tf.Variable(tf.constant(0.1, shape=[target.get_shape()[1]]))
prediction = (tf.matmul(last, weight) + bias)*(max_train-min_train) + min_train

cost = tf.losses.mean_squared_error(prediction, target)
optimizer = tf.train.RMSPropOptimizer(learning_rate = learn_rate).minimize(cost)

init_op = tf.global_variables_initializer()
saver = tf.train.Saver()
sess = tf.Session()
sess.run(init_op)

# restore trained model
saver.restore(sess, "../../../trained_model/I280-S/PDELSTM_45m/m"+str(m)+"_"+str(epoch)+"_"+str(num_hidden)+"_"+str(batch_size)+".ckpt")

# get the predicted results
pred = sess.run(tf.round(prediction), feed_dict={data: X_test})

# evaluation metrics
mae = np.mean(np.abs(pred-np.array(Y_test)))
mse = np.mean(np.power(np.abs(pred-np.array(Y_test)),2))
rmse = np.sqrt(mse)
mape = np.mean(np.abs(pred-np.array(Y_test)) / np.abs(np.array(Y_test)))*100

# save the predicted flow
np.savetxt('../../../predicted_flow/I280-S/PDELSTM_45m/pdelstm_predicted_45m.csv',pred,delimiter=",")

print ("MAE: ", str(mae))
print ("RMSE: ", str(rmse))
print ("MAPE: ", str(mape), "%")
sess.close()
print (datetime.now()-start)
